/**
 * Copyright (c) 2018 Microsoft Open Technologies, Inc.
 *
 *    Licensed under the Apache License, Version 2.0 (the "License"); you may
 *    not use this file except in compliance with the License. You may obtain
 *    a copy of the License at http://www.apache.org/licenses/LICENSE-2.0
 *
 *    THIS CODE IS PROVIDED ON AN *AS IS* BASIS, WITHOUT WARRANTIES OR
 *    CONDITIONS OF ANY KIND, EITHER EXPRESS OR IMPLIED, INCLUDING WITHOUT
 *    LIMITATION ANY IMPLIED WARRANTIES OR CONDITIONS OF TITLE, FITNESS
 *    FOR A PARTICULAR PURPOSE, MERCHANTABILITY OR NON-INFRINGEMENT.
 *
 *    See the Apache Version 2.0 License for specific language governing
 *    permissions and limitations under the License.
 *
 *    Microsoft would like to thank the following companies for their review and
 *    assistance with these files: Intel Corporation, Mellanox Technologies Ltd,
 *    Dell Products, L.P., Facebook, Inc., Marvell International Ltd.
 *
 * @file    saitunnelextensions.h
 *
 * @brief   This module defines bridge extensions of the Switch Abstraction Interface (SAI)
 */

#ifndef __SAITUNNELEXTENSIONS_H_
#define __SAITUNNELEXTENSIONS_H_

#include <saitypes.h>
#include <saitunnel.h>

/**
 * @brief Enum defining tunnel orientation types.
 */
typedef enum _sai_tunnel_experimental_orientation_type_t
{
    SAI_TUNNEL_EXPERIMENTAL_ORIENTATION_TYPE_0 = 0,

    SAI_TUNNEL_EXPERIMENTAL_ORIENTATION_TYPE_1,

    SAI_TUNNEL_EXPERIMENTAL_ORIENTATION_TYPE_2,

} sai_tunnel_experimental_orientation_type_t;

/**
 * @brief SAI tunnel attribute extensions.
 *
 * @flags free
 */
typedef enum _sai_tunnel_attr_extensions_t
{
    /**
     * @brief Tunnel Orientation for split horizon
     *
     * @type sai_tunnel_experimental_orientation_type_t
     * @flags CREATE_AND_SET
     * @default SAI_TUNNEL_EXPERIMENTAL_ORIENTATION_TYPE_0
     * @validonly SAI_TUNNEL_ATTR_PEER_MODE == SAI_TUNNEL_PEER_MODE_P2P
     */
    SAI_TUNNEL_ATTR_EXPERIMENTAL_ORIENTATION_TYPE = SAI_TUNNEL_ATTR_END,

} sai_tunnel_attr_extensions_t;

#endif /* __SAITUNNELEXTENSIONS_H_ */
